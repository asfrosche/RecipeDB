import os

print(os.getenv('DB_HOSTNAME'))